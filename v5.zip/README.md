# Semua Tools Kz — Pterodactyl v5

Versi ini meniru UI dari video referensi: hero anime ungu, status card, tab All/Downloader/Maker/Tools, grid 3 kolom, bottom navigation, dan bottom-sheet modal.

## Install
```bash
npm install && npm start
```

## Environment
```env
SOCIALKIT_ACCESS_KEY=API_KEY_SOCIALKIT_KAMU
```

Remove BG dan Image Enhancer menggunakan provider CleverUtils tanpa API key pada versi ini. IQC, Windows Quotes, dan Meme Tanya Ustadz diproses lokal di browser.

Jangan taruh API key di index.html.
