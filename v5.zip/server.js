require("dotenv").config();
const express = require("express");
const path = require("path");
const multer = require("multer");

const app = express();
const PORT = Number(process.env.SERVER_PORT || process.env.PORT || 3000);
const HOST = "0.0.0.0";
const SOCIALKIT_KEY = process.env.SOCIALKIT_ACCESS_KEY;

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 30 * 1024 * 1024 }
});

app.use(express.json({ limit: "4mb" }));
app.use(express.static(path.join(__dirname, "public")));

function providerError(res, response, fallback) {
  return response.text().then(raw => {
    let data = {};
    try { data = raw ? JSON.parse(raw) : {}; } catch { data = { raw }; }
    const msg = data?.error?.message || data?.error || data?.message || fallback;
    return res.status(response.status).json({ error: msg, provider: data });
  });
}

function requireEnv(res, key, label) {
  if (!key) {
    res.status(501).json({
      error: `${label} belum diisi di environment Pterodactyl (.env).`
    });
    return false;
  }
  return true;
}

function validPlatform(p) {
  return ["tiktok", "instagram", "youtube"].includes(p);
}

app.get("/api/health", (req, res) => res.json({
  ok: true,
  socialkitConfigured: Boolean(SOCIALKIT_KEY),
  imageToolsProvider: "CleverUtils (no API key)",
}));

// ---------------- SocialKit downloader ----------------
app.post("/api/download/:platform", async (req, res) => {
  const platform = req.params.platform;
  if (!validPlatform(platform)) return res.status(400).json({ error: "Platform tidak didukung" });
  if (!requireEnv(res, SOCIALKIT_KEY, "SOCIALKIT_ACCESS_KEY")) return;

  const { url, quality = "480p", format = "mp4" } = req.body || {};
  if (!url) return res.status(400).json({ error: "URL wajib diisi" });

  try {
    const response = await fetch(`https://api.socialkit.dev/v2/${platform}/download`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-access-key": SOCIALKIT_KEY },
      body: JSON.stringify({ url, quality, format })
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) return res.status(response.status).json({
      error: data?.message || data?.error || `SocialKit HTTP ${response.status}`,
      data
    });
    const jobId = data?.data?.jobId || data?.jobId || null;
    if (!jobId) return res.status(502).json({
      error: data?.message || "SocialKit tidak mengembalikan jobId.", socialkit: data
    });
    res.json({ success: true, jobId, status: data?.data?.status || data?.status || "queued", data: data?.data || data });
  } catch (err) {
    res.status(502).json({ error: "Tidak dapat terhubung ke SocialKit: " + err.message });
  }
});

app.get("/api/download/status/:jobId", async (req, res) => {
  if (!requireEnv(res, SOCIALKIT_KEY, "SOCIALKIT_ACCESS_KEY")) return;
  try {
    const response = await fetch(`https://api.socialkit.dev/v2/downloads/${encodeURIComponent(req.params.jobId)}`, {
      headers: { "x-access-key": SOCIALKIT_KEY }
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) return res.status(response.status).json({ error: data?.message || data?.error || `SocialKit HTTP ${response.status}`, data });
    res.json({ success: data?.success !== false, data: data?.data || data });
  } catch (err) {
    res.status(502).json({ error: "Tidak dapat mengecek SocialKit: " + err.message });
  }
});

app.get("/api/credits", async (req, res) => {
  if (!requireEnv(res, SOCIALKIT_KEY, "SOCIALKIT_ACCESS_KEY")) return;
  try {
    const response = await fetch("https://api.socialkit.dev/credits", { headers: { "x-access-key": SOCIALKIT_KEY } });
    const data = await response.json().catch(() => ({}));
    res.status(response.status).json(data);
  } catch (err) { res.status(502).json({ error: err.message }); }
});

// ---------------- Image tools (CleverUtils, no API key) ----------------
async function cleverImageTool(res, req, slug, fields = {}) {
  if (!req.file) return res.status(400).json({ error: "Pilih gambar terlebih dahulu." });
  if (!/^image\/(png|jpeg|webp|bmp|tiff)$/.test(req.file.mimetype)) {
    return res.status(400).json({ error: "Format harus PNG, JPG/JPEG, WebP, BMP, atau TIFF." });
  }

  try {
    const form = new FormData();
    form.append("file", new Blob([req.file.buffer], { type: req.file.mimetype }), req.file.originalname || "image");
    for (const [k, v] of Object.entries(fields)) form.append(k, String(v));

    const response = await fetch(`https://cleverutils.com/api/v1/tools/${slug}`, {
      method: "POST",
      body: form
    });

    const raw = await response.text();
    let data = {};
    try { data = raw ? JSON.parse(raw) : {}; } catch {}
    if (!response.ok) {
      const msg = data?.error?.message || data?.error || data?.message || `CleverUtils HTTP ${response.status}`;
      return res.status(response.status).json({ error: msg, provider: data });
    }

    let job = data?.data || data;
    // CleverUtils may finish small jobs immediately or return a processing job.
    if (job?.status === "processing" && job?.job_id) {
      for (let i = 0; i < 45; i++) {
        await new Promise(r => setTimeout(r, 2000));
        const poll = await fetch(`https://cleverutils.com/api/v1/jobs/${encodeURIComponent(job.job_id)}`);
        const pd = await poll.json().catch(() => ({}));
        job = pd?.data || pd;
        if (job?.status === "done" || job?.status === "failed" || job?.status === "error") break;
      }
    }

    if (job?.status === "failed" || job?.status === "error") {
      return res.status(502).json({ error: job?.error?.message || job?.error || "Pemrosesan gambar gagal.", provider: job });
    }

    const outputUrl = job?.output?.url || job?.output_url || job?.download_url || job?.links?.output;
    if (!outputUrl) return res.status(502).json({ error: "CleverUtils tidak mengembalikan hasil gambar.", provider: data });

    const out = await fetch(outputUrl);
    if (!out.ok) return res.status(502).json({ error: `Gagal mengambil hasil gambar (HTTP ${out.status}).` });
    const buffer = Buffer.from(await out.arrayBuffer());
    res.setHeader("Content-Type", out.headers.get("content-type") || (slug === "remove-background" ? "image/png" : "image/jpeg"));
    res.setHeader("Content-Disposition", `inline; filename="${slug === "remove-background" ? "remove-bg.png" : "enhanced-image.png"}"`);
    res.send(buffer);
  } catch (err) {
    res.status(502).json({ error: "Gagal menghubungi CleverUtils: " + err.message });
  }
}

app.post("/api/remove-bg", upload.single("image"), async (req, res) => {
  return cleverImageTool(res, req, "remove-background");
});

app.post("/api/enhance", upload.single("image"), async (req, res) => {
  const scale = Number(req.body?.scale || 2);
  if (![2, 3, 4].includes(scale)) return res.status(400).json({ error: "Skala harus 2×, 3×, atau 4×." });
  return cleverImageTool(res, req, "upscale-image", { scale });
});

app.listen(PORT, HOST, () => {
  console.log(`Semua Tools berjalan di http://${HOST}:${PORT}`);
  console.log(`SocialKit: ${Boolean(SOCIALKIT_KEY)} | CleverUtils image tools: ON (no API key) | Meme tools: local`);
});
